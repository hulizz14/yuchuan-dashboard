# 禹川集团2026年工作看板

📱 手机访问地址：https://602398037.github.io/yuchuan-dashboard

## 看板清单

1. **总览导航** - index.html
2. **财富中心看板 V5** - caifu.html
3. **物业公司看板 V2** - wuye.html  
4. **工程部看板** - gongcheng.html
5. **成本部看板** - chengben.html
6. **开发部看板** - kaifa.html
7. **财务部看板** - caiwu.html
8. **人力行政+法务看板** - renli.html
9. **营销部看板** - yingxiao.html

## 更新日志

- 2026-03-05: 初始版本发布
